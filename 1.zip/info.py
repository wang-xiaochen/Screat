import requests
from bs4 import BeautifulSoup
import csv


# 获取每页内容
def get_one_page(url):
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/95.0.4638.69 Safari/537.36'
    }
    try:
        info_list_page = []  # 一页的所有信息
        resp = requests.get(url, headers=headers)
        resp.encoding = resp.status_code
        page_text = resp.text
        soup = BeautifulSoup(page_text, 'lxml')
        li_list = soup.select('.left-list > ul > li')  # 找到所有li标签
        for li in li_list:
            divs = li.select('div')
            date = divs[0].string.strip()
            title = divs[1].a.string
            info = [date, title]
            info_list_page.append(info)
    except Exception as e:
        print('爬取' + url + '错误')
        print(e)
        return None
    else:
        resp.close()
    print('爬取' + url + '成功')
    return info_list_page


# main
def main():
    # 爬取所有数据
    info_list_all = []
    base_url = 'http://news.cqjtu.edu.cn/xxtz/'
    for i in range(1, 67):
        if i == 1:
            url = 'http://news.cqjtu.edu.cn/xxtz.htm'
        else:
            url = base_url + str(67 - i) + '.htm'
        info_list_page = get_one_page(url)
        info_list_all += info_list_page
    # 存入数据
    with open('教务新闻.csv', 'w', newline='', encoding='utf-8') as file:
        fileWriter = csv.writer(file)
        fileWriter.writerow(['日期', '标题'])  # 写入表头
        fileWriter.writerows(info_list_all)  # 写入数据


if __name__ == '__main__':
    main()
